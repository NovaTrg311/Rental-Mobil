package koneksi.java;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



/**
 *
 * @author Sidiq
 */
public class conection {

    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver"); // <- Sudah benar

                connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/rental_mobil", "root", "");

                System.out.println("Driver ditemukan");

            } catch (SQLException ex) {
                System.out.println("Error koneksi: " + ex.getMessage());
            } catch (ClassNotFoundException e) {
                System.out.println("Driver tidak ditemukan: " + e.getMessage());
            }
        }
        return connection;
    } 
}
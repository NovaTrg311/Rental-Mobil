Tutor :
- Buat database dengan nama rental_mobil 
- import database rental_mobil.sql 
- ini merupakan versi beta silahkan di kembangkan sesuai imajinasi masing masing
- saat project sudah running silahkan gunakan akun 

> Username: admin dan Password: admin untuk masuk sebagai Admin
> Username: staff dan Password: staff untuk masuk sebagai Staff